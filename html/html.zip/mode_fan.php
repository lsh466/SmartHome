<?php

$output = shell_exec('irsend SEND_ONCE sunp KEY_MODE');
echo "mode</br>";
echo "<pre>$output</pre>";
?>

