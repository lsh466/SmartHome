<?php
	echo shell_exec("sudo whoami");
?>
