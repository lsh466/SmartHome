<?php

$output = shell_exec('sudo python dht_info.py');

echo "$output";
?>
