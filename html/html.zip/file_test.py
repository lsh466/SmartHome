f = open('manual_mode.txt', 'r')

val = f.read()

print(val)

f = open('manual_mode.txt', 'r')

val = f.read()

print(val)

f.close()
