<?php

$output = shell_exec('irsend SEND_ONCE sunp KEY_POWER');
echo "power</br>";
echo "<pre>$output</pre>";
?>
